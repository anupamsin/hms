package com.foodies.seurity_service.entities;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserAuthenticationDetais {
	@Column(nullable = false, unique = true, length = 30)
	private String userName;
	
	@Column(nullable = false, unique = true)
	private String email;
	
	@Column(nullable = false, unique = true, length = 10)
	private String phoneNumber;
	
	@Column(name = "user_password", nullable = false)
	private String password;
}
