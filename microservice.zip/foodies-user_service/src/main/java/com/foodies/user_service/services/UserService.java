package com.foodies.user_service.services;

import java.util.List;

import com.foodies.user_service.dto.UserDTO;
import com.foodies.user_service.dto.UserDeletedDTO;

public interface UserService {
	UserDTO createUser(UserDTO userDTO);

	List<UserDTO> getAllUsers();

	UserDeletedDTO deleteUserById(String userId);

	UserDTO getUserDetailsById(String userId);
}
