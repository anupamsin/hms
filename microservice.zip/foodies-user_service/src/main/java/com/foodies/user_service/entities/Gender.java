package com.foodies.user_service.entities;

public enum Gender {
	MALE, FEMALE, OTHERS
}
