package com.foodies.user_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodiesUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodiesUserServiceApplication.class, args);
	}

}
