package com.foodies.user_service.utilities;

import org.springframework.beans.BeanUtils;

import com.foodies.user_service.dto.UserDTO;
import com.foodies.user_service.entities.User;

public class DTO_Utilities {
	public static UserDTO covertUserToUserDTO(User user) {
		UserDTO dto=new UserDTO();
		BeanUtils.copyProperties(user, dto);
		return dto;
	}
	
	/*
	 * public static User covertUserDTOToUser(UserDTO userDTO) { User user=new
	 * User(); user.setUserId(userDTO.getUserId());
	 * user.setBirthDate(userDTO.getBirthDate()); user.setEmail(userDTO.getEmail());
	 * user.setFirstName(userDTO.getFirstName());
	 * user.setGender(userDTO.getGender()); user.setLastName(userDTO.getLastName());
	 * user.setPassword(userDTO.getPassword());
	 * user.setPhoneNumber(userDTO.getPhoneNumber());
	 * user.setUserName(userDTO.getUserName());
	 * BeanUtils.copyProperties(user,userDTO); return user; }
	 */
}
