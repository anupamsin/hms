package com.foodies.user_service.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "users")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User {
	@Id
	private String userId;

	/*
	 * @Column(nullable = false, unique = true, length = 30)
	 * 
	 * private String userName;
	 * 
	 * @Column(nullable = false, unique = true)
	 * 
	 * private String email;
	 * 
	 * @Column(nullable = false, unique = true, length = 10)
	 * 
	 * private String phoneNumber;
	 * 
	 * @Column(name = "user_password", nullable = false)
	 * 
	 * private String password;
	 */

	private String firstName;

	private String lastName;

	private LocalDate birthDate;

	@Enumerated(EnumType.STRING)
	private Gender gender;
	/*
	 * @Transient
	 * 
	 * @Builder.Default private ArrayList<Address> addresses=new ArrayList<>();
	 */

	@Transient
	private UserAuthenticationDetais userAuthenticationDetais;
}
