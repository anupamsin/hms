package com.foodies.user_service.dto;

import java.time.LocalDate;
import java.util.ArrayList;

import com.foodies.user_service.entities.Gender;
import com.foodies.user_service.entities.location.Address;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Past;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDTO {

	private String userId;

	/*
	 * @NotBlank(message = "username can not be empty") private String userName;
	 * 
	 * @NotBlank(message = "email can not be empty") private String email;
	 * 
	 * @NotEmpty(message = "Phone Number Can't Be Empty") private String
	 * phoneNumber;
	 * 
	 * @NotEmpty(message = "Password can not be empty")
	 * 
	 * @Size(min = 8, max = 120, message = "Password length must be greater than 8")
	 * private String password;
	 */

	@NotEmpty(message = "First name Can't be Empty")
	private String firstName;

	@NotBlank(message = "Last Name can not be empty")
	private String lastName;

	@Past(message = "Birthdate must be of past date")
	@NotEmpty(message = "Birthdate Can't be Empty")
	private LocalDate birthDate;

	@NotEmpty(message = "DOB Can't be Empty")
	private Gender gender;
	
	@Builder.Default
	private ArrayList<Address> addresses = new ArrayList<>();
}
