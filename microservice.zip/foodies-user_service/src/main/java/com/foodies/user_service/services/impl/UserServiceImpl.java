package com.foodies.user_service.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foodies.user_service.dto.UserDTO;
import com.foodies.user_service.dto.UserDeletedDTO;
import com.foodies.user_service.entities.User;
import com.foodies.user_service.exception.UserNotFoundException;
import com.foodies.user_service.repositories.UserRepository;
import com.foodies.user_service.services.UserService;
import static com.foodies.user_service.utilities.DTO_Utilities.covertUserToUserDTO;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDTO createUser(UserDTO userDTO) {
		User user=new User();
		String userId=UUID.randomUUID().toString();
		userDTO.setUserId(userId);
		user.setUserId(userDTO.getUserId());
		user.setBirthDate(userDTO.getBirthDate());
		//user.setEmail(userDTO.getEmail());
		user.setFirstName(userDTO.getFirstName());
		user.setGender(userDTO.getGender());
		user.setLastName(userDTO.getLastName());
		//user.setPassword(userDTO.getPassword());
		//user.setPhoneNumber(userDTO.getPhoneNumber());
		//user.setUserName(userDTO.getUserName());
		userRepository.save(user);
		return covertUserToUserDTO(user);
	}

	@Override
	public List<UserDTO> getAllUsers() {
		List<User> list=userRepository.findAll();
		List<UserDTO> listDto=new ArrayList<>();
		list.forEach(user->{
			listDto.add(covertUserToUserDTO(user));
		});
		return listDto;
	}

	@Override
	public UserDeletedDTO deleteUserById(String userId) {
		User user=userRepository.findById(userId).orElseThrow(()->new UserNotFoundException("User with id : "+userId+" not found"));
		UserDTO userDTO=covertUserToUserDTO(user);
		UserDeletedDTO userDeletedDTO=new UserDeletedDTO();	
		if(user!=null) {			
			userRepository.delete(user);
			userDeletedDTO.setDeletedUserData(userDTO);
			userDeletedDTO.setMessage("User Deleted Successfully");
		}
		return userDeletedDTO;
	}

	@Override
	public UserDTO getUserDetailsById(String userId) {
		User user=userRepository.findById(userId).orElseThrow(()->new UserNotFoundException("User with id : "+userId+" not found"));
		return covertUserToUserDTO(user);
	}	
	
}
