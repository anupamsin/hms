package com.foodies.user_service.exception;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	 @ExceptionHandler(UserNotFoundException.class)
	 public ResponseEntity<API_Error_Response> handlerResourceNotFoundException(UserNotFoundException ex){
	        String message=ex.getMessage();
	        API_Error_Response response= API_Error_Response.builder().message(message).success(true).httpStatus(HttpStatus.NOT_FOUND).build();
	        return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	   } 
	    
	 @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
	 public ResponseEntity<API_Error_Response> handlerForVAlidationError(SQLIntegrityConstraintViolationException ex){
		 String message=ex.getMessage();
	        API_Error_Response response= API_Error_Response.builder().message(message).success(true).httpStatus(HttpStatus.NOT_FOUND).build();
	        return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	 }
}
