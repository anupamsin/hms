package com.hms.user.service.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.user.service.entities.Hotel;
import com.hms.user.service.entities.Rating;
import com.hms.user.service.entities.User;
import com.hms.user.service.exception.ResourceNotFoundException;
import com.hms.user.service.external.services.HotelService;
import com.hms.user.service.external.services.RatingService;
import com.hms.user.service.repositories.UserRepository;
import com.hms.user.service.services.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	/*
	 * @Autowired private RestTemplate restTemplate;
	 */

	@Autowired
	private HotelService hotelService;

	@Autowired
	private RatingService ratingService;

	// private Logger logger=LoggerFactory.getLogger(UserService.class);

	@Override
	public User saveUser(User user) {
		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUser() {
		// implement rating service all
		List<User> userList = userRepository.findAll();
		List<User> user=new ArrayList<>();

		for (User u : userList) {
			List<Rating> ratings = ratingService.getRatingsByUserId(u.getUserId());
			for(Rating r : ratings) {
				Hotel hotel=hotelService.getHotel(r.getHotelId());
				r.setHotel(hotel);
			}
			u.setRatings(ratings);
			user.add(u);
		}

		return user;
	}

	@Override
	public User getUser(String userId) {
		// get user from db with the help of user repository
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("user given With Id " + userId + " is not found"));
		// get rating of the above user from rating service
		// http://localhost:8083/ratings/users/a48509cd-f26d-4eb8-b4d5-ce8fbe19d90c
		// Rating[] ratingsByUserId=
		// restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+user.getUserId(),Rating[].class);
		// List<Rating> ratings=Arrays.stream(ratingsByUserId).toList();
		List<Rating> ratings = ratingService.getRatingsByUserId(userId);
		List<Rating> ratingList = ratings.stream().map(rating -> {
			// api call to hotel service to gethotel
			// http://localhost:8082/hotels/21a476af-98e0-440f-b924-09af242c3e0f
			// ResponseEntity<Hotel>
			// forEntity=restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/"+rating.getHotelId(),
			// Hotel.class);
			Hotel hotel = hotelService.getHotel(rating.getHotelId());
			// Hotel hotel=forEntity.getBody();
			// logger.info("response status code:",forEntity.getStatusCode());
			// set the hotel to rating
			rating.setHotel(hotel);
			// return the rating
			return rating;
		}).collect(Collectors.toList());
		user.setRatings(ratingList);
		return user;
	}
}
