package com.hms.user.service.controllers;

import com.hms.user.service.entities.User;
import com.hms.user.service.services.UserService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    
    private Logger logger=LoggerFactory.getLogger(UserController.class);
    
    //create
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
        User user1=userService.saveUser(user);
        return new ResponseEntity<>(user1,HttpStatus.CREATED);
    }
    
    int retryCount=1;
    //single user get
    @GetMapping("/{userId}")
    //@CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod = "ratingHotelFallback")
    @Retry(name = "ratingHotelService",fallbackMethod = "ratingHotelFallback")
    public ResponseEntity<User> getSingleUser(@PathVariable String userId){
    	logger.info("Retry Count : {}",retryCount);
    	retryCount++;
        User user= userService.getUser(userId);
        return new ResponseEntity<>(user,HttpStatus.OK);
    }
    
    //creating fall back method for circuit breaker
    public ResponseEntity<User> ratingHotelFallback(String userId, Exception ex){
    	logger.info("Fallback executed as service is down : ",ex.getMessage());
    	User user= User.builder().email("dummy@email.com").name("dummy").about("This user is created as services are down").userId("123456").build();
    	return new ResponseEntity<>(user,HttpStatus.OK);
    }
    
    // all user get
    @GetMapping
    @CircuitBreaker(name = "listOfAllUser",fallbackMethod = "listOfAllUserFallback")
    public ResponseEntity<List<User>> getAlluser(){
        List<User> users= userService.getAllUser();
        return new ResponseEntity<>(users,HttpStatus.OK);
    }
    
    public ResponseEntity<List<User>> listOfAllUserFallback(Exception ex){
    	logger.info("Fallback executed as service is down : ",ex.getMessage());
        List<User> users= new ArrayList<>();
        users.add(User.builder().email("dummy1@email.com").name("dummy1").about("This user is created as services are down").userId("123456").build());
        users.add(User.builder().email("dummy2@email.com").name("dummy2").about("This user is created as services are down").userId("1234567").build());
        return new ResponseEntity<>(users,HttpStatus.OK);
    }
}
