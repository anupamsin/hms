package com.hms.hotel.exception;

public class ResourceNotFoundException extends RuntimeException{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1006476801838242041L;

	public ResourceNotFoundException(){
        super("Resource Not Found on server !!");
    }

    public ResourceNotFoundException(String message){
        super(message);
    }
}
