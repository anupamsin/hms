package com.hms.hotel.services;

import com.hms.hotel.entities.Hotel;

import java.util.List;

public interface HotelService {
    //create
    Hotel createHotel(Hotel hotel);

    //get all
    List<Hotel> getAll();

    //get single
    Hotel get(String hotelId);
}
