package com.hms.rating.services;

import com.hms.rating.entities.Rating;

import java.util.List;

public interface RatingService {
    //create
    Rating create(Rating rating);

    //get all ratings
    List<Rating> getAllRatings();

    //get all ratings by userid
    List<Rating> getRatingByUserId(String userId);

    //get rating by hotel
    List<Rating> getRatingByHotelId(String hotelId);
}
